import React from 'react';
import Slide from "./slide";
import { useEffect, useState } from 'react';

// const Slider = (props) => {
    const Slider = () => {

    let [slide, setSlide] = useState({ data: { pets: [] } });
    let [show, setShow] = useState({ display: 'flex' });


    var reqestOptions;

    useEffect(() => req_slide(slide, setSlide), []);
    function req_slide(slide, setSlide) {
        reqestOptions = {
            method: 'GET',
        };
    }



    fetch("https://pets.сделай.site/api/pets/slider", reqestOptions)
        .then(response => response.json())
        .then(result => {
            console.log(result)
            setSlide(result)
            setShow({ display: 'none' });

        })
        .catch(error => console.log('error', error));

    if (slide.data.pets == 0){
        return;
    }
    
    


    let slides = slide.data.pets.map((pet, index) => {
        let tmpClass = "carousel-item";

        if (index == 0) {            
            tmpClass += " active";
        }       

        return <Slide data={pet} key={index} css_class={tmpClass} />;

    })

    // let indicators = slide.data.pets.map((pet, index) => {
    //     if (index == 0) {
    //         return <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1" key={index + 'btn'}></button>
    //     } else {
    //         return <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to={index} aria-lebel={"Slide" + (Number(index) + 1)} key={index + 'btn'}></button>
    //     }
    // })

    // let tmpSliderHtml = "";


    debugger;

    return (
        <>
            <div
                id="carouselExampleCaptions"
                className="carousel slide"
                data-bs-ride="carousel"
            >

                <div className="carousel-indicators">

                    <button
                        type="button"
                        data-bs-target="#carouselExampleCaptions"
                        data-bs-slide-to={0}
                        className="active"
                        aria-current="true"
                        aria-lebel="Slide 1"
                    />
                    <button
                        type="button"
                        data-bs-target="#carouselExampleCaptions"
                        data-bs-slide-to={1}
                        aria-lebel="Slide 2"
                    />
                    <button
                        type="button"
                        data-bs-target="#carouselExampleCaptions"
                        data-bs-slide-to={2}
                        aria-lebel="Slide 3"
                    />
                </div>

                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <img src={"https://place-hold.it/300x200?text=1"} className="d-block w-100" alt="..." style={{ backgroundColor: "#c4ecbd" }} />
                    </div>
                    <div className="carousel-caption d-none d-md-block">
                        <h5>Third slide label</h5>
                        <p>Some representative placeholder content for the third slide.</p>
                    </div>

                    {slides}  

                </div>

            </div>

            <button
                className="carousel-control-prev"
                tupe="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev"
            >

                <span className="carosel-control-prev-icon" aria-hidden="true" />
                <span className="visually-hidden"> Предыдущий</span>
            </button>

            <button
                className="carousel-control-next"
                tupe="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">

                <span className="carosel-control-next-icon" aria-hidden="true" />
                <span className="visually-hidden">Следующий</span>
            </button>
        </>
    );
};

export default Slider;
